﻿#pragma once

struct Vertex;

class VertexArray
{
public:
	// конструктор солздаст VAO и VBO на видеокарте
	VertexArray();

	// Деструктор очистит память вдиеокарты при удалении объекта
	~VertexArray();

	VertexArray(const VertexArray&) = delete;
	VertexArray& operator=(const VertexArray&) = delete;
	VertexArray(VertexArray&& other) noexcept;
	VertexArray& operator=(VertexArray&& other) noexcept;

	// Загрузить вершины в видеопамятьи настроть атрибуты 
	void SetData(const Vertex* vertices, unsigned int vCount, const unsigned int* indicdes, unsigned int iSize);

	// Активировать этот VertexArray для отрисовкеи
	void Bind() const;

	// Деактивировать (отвязать)
	void UnBind() const;

private:
	unsigned int m_VAO; // ID контейнера настроек
	unsigned int m_VBO; // ID буфера с сырыми данными вершин
	unsigned int m_EBO; // Порядок соединения вершин
};